/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();
        EmployeeManagement empManager = new EmployeeManagement();
        PayrollManager payrollManager = new PayrollManager();

        System.out.println("********Welcome to Payroll Management System!********");

        
        login.login(); 

        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Employee Management");
            System.out.println("2. Payroll Management");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1 -> manageEmployeeData(empManager, scanner);
                    case 2 -> managePayrollData(empManager, payrollManager, scanner);
                    case 3 -> {
                        System.out.println("Exiting Payroll Management System. Goodbye!");
                        return; 
                    }
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void manageEmployeeData(EmployeeManagement empManager, Scanner scanner) {
        while (true) {
            System.out.println("\nEmployee Management Menu:");
            System.out.println("1. Add Full-Time Employee");
            System.out.println("2. Add Part-Time Employee");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                   
                    case 1 -> {
                        int id = getValidId(scanner);
                        String name = getValidInput(scanner, "Name", "[a-zA-Z\\s]+", "Name must contain only letters.");
                        String gender = getValidInput(scanner, "Gender", "[a-zA-Z]+", "Gender must contain only letters.");
                        String email = getValidInput(scanner, "Email", ".+", "Email cannot be empty.");
                        String dob = getValidInput(scanner, "Date of Birth (DOB)", "\\d{2}-\\d{2}-\\d{4}", "Date of birth must follow the format DD-MM-YYYY.");
                        String department = getValidInput(scanner, "Department", ".+", "Department cannot be empty.");

                        FullTimeEmployee emp = new FullTimeEmployee(id, name, gender, email, dob, department);
                        empManager.addEmployee(emp);
                        System.out.println("Full-Time Employee added successfully!");
                    }
                    case 2 -> {
                        int id = getValidId(scanner);
                        String name = getValidInput(scanner, "Name", "[a-zA-Z\\s]+", "Name must contain only letters.");
                        String gender = getValidInput(scanner, "Gender", "[a-zA-Z]+", "Gender must contain only letters.");
                        String email = getValidInput(scanner, "Email", ".+", "Email cannot be empty.");
                        String dob = getValidInput(scanner, "Date of Birth (DOB)", "\\d{2}-\\d{2}-\\d{4}", "Date of birth must follow the format DD-MM-YYYY.");
                        String department = getValidInput(scanner, "Department", ".+", "Department cannot be empty.");
                        System.out.print("Enter Hours Worked: ");
                        int hoursWorked = scanner.nextInt();

                        PartTimeEmployee emp = new PartTimeEmployee(id, name, gender, email, dob, department, hoursWorked);
                        empManager.addEmployee(emp);
                        System.out.println("Part-Time Employee added successfully!");
                    }
                    case 3 -> {
                        int id = getValidId(scanner);
                        String newEmail = getValidInput(scanner, "New Email", ".+", "Email cannot be empty.");
                        empManager.updateEmployee(id, newEmail);
                        System.out.println("Employee updated successfully!");
                    }
                    case 4 -> {
                        int id = getValidId(scanner);
                        empManager.deleteEmployee(id);
                        System.out.println("Employee deleted successfully!");
                    }
                    case 5 -> {
                        return; // Back to main menu
                    }
                    default -> System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static int getValidId(Scanner scanner) {
        while (true) {
            System.out.print("Enter Employee ID: ");
            try {
                int id = Integer.parseInt(scanner.next());
                if (id > 0) return id;
                else System.out.println("ID must be greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a numeric ID.");
            }
        }
    }

    private static String getValidInput(Scanner scanner, String fieldName, String regex, String errorMsg) {
        scanner.nextLine(); // Consume leftover newline
        while (true) {
            System.out.print("Enter " + fieldName + ": ");
            String input = scanner.nextLine().trim();
            if (input.matches(regex)) return input;
            System.out.println("Invalid " + fieldName + ". " + errorMsg);
        }
    }

    

    private static void managePayrollData(EmployeeManagement empManager, PayrollManager payrollManager, Scanner scanner) {
    while (true) {
        System.out.println("\nPayroll Management Menu:");
        System.out.println("1. Calculate Salary");
        System.out.println("2. Calculate Allowances");
        System.out.println("3. Update Salary");
        System.out.println("4. Delete Salary");
        System.out.println("5. Update Allowance");
        System.out.println("6. Delete Allowance");
        System.out.println("7. Back to Main Menu");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        try {
            switch (choice) {
                case 1 -> {
                   
                    System.out.print("Enter Employee ID to calculate salary: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    List<Employee> employees = Employee.loadFromFile();
                    Employee emp = employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);

                    if (emp != null) {
                        double baseSalary = getDoubleInput(scanner, "Base Salary");
                        double deductions = getDoubleInput(scanner, "Deductions");
                        double bonuses = getDoubleInput(scanner, "Bonuses");
                         Salary salary = new Salary(baseSalary, deductions, bonuses);
                     double netSalary = salary.calculateNetSalary();
                     System.out.println("Net Salary for " + emp.getName() + ": " + netSalary);

                     salary.saveToFile();
                        
                    } else {
                        System.out.println("Employee not found.");
                    }
                }
                case 2 -> {
                    // Calculate Allowances
                    System.out.print("Enter Employee ID to calculate allowances: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    List<Employee> employees = Employee.loadFromFile();
                    Employee emp = employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);

                    if (emp != null) {
                        double transportAllowance = getDoubleInput(scanner, "Transport Allowance");
                        double housingAllowance = getDoubleInput(scanner, "Housing Allowance");
                        double mealAllowance = getDoubleInput(scanner, "Meal Allowance");
                        double medicalAllowance = getDoubleInput(scanner, "Medical Allowance");
                        double otherAllowances = getDoubleInput(scanner, "Other Allowances");

                        double netAllowance = emp.calculateAllowances(transportAllowance, housingAllowance, mealAllowance, medicalAllowance, otherAllowances);
                        System.out.println("Net Allowance for " + emp.getName() + ": " + netAllowance);
                    } else {
                        System.out.println("Employee not found.");
                    }
                }
                case 3 -> {
                    // Update Salary
                    System.out.print("Enter Employee ID to update salary: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    List<Employee> employees = Employee.loadFromFile();
                    Employee emp = employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);

                    if (emp != null) {
                        double newBasesalary = getDoubleInput(scanner, "New Base Salary");
                        double newBonuses = getDoubleInput(scanner, "New Bonuses");
                        double newDeductions = getDoubleInput(scanner, "New Deductions");
                         Salary salary = new Salary(newBasesalary, newDeductions, newBonuses);
                     double netSalary = salary.calculateNetSalary();
                     System.out.println("Net Salary for " + emp.getName() + ": " + netSalary);

                      
                        
                        System.out.println("Salary updated for " + emp.getName());
                        
                    } else {
                        System.out.println("Employee not found.");
                    }
                }
                case 4 -> {
                    // Delete Salary
                    System.out.print("Enter Employee ID to delete salary: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    List<Employee> employees = Employee.loadFromFile();
                    Employee emp = employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);

                    if (emp != null) {
                        emp.setSalary(0);
                        System.out.println("Salary deleted for " + emp.getName());
                        
                    } else {
                        System.out.println("Employee not found.");
                    }
                }
                case 5 -> {
                    // Update Allowance
                    System.out.print("Enter Employee ID to update allowance: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    List<Employee> employees = Employee.loadFromFile();
                    Employee emp = employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);

                    if (emp != null) {
                        
                        double newTransportAllowance = getDoubleInput(scanner, "New Transport Allowance");
                        double newHousingAllowance = getDoubleInput(scanner, "New Housing Allowance");
                        double newMealAllowance = getDoubleInput(scanner, "New Meal Allowance");
                        double newMedicalAllowance = getDoubleInput(scanner, "New Medical Allowance");
                        double newOtherAllowances = getDoubleInput(scanner, "New Other Allowances");
                       double netAllowance = emp.calculateAllowances(newTransportAllowance, newHousingAllowance, newMealAllowance, newMedicalAllowance, newOtherAllowances);
                        System.out.println("Net Allowance for " + emp.getName() + ": " + netAllowance);
                        System.out.println("Allowance updated for " + emp.getName());
                        
                    } else {
                        System.out.println("Employee not found.");
                    }
                }
                case 6 -> {
                    // Delete Allowance
                    System.out.print("Enter Employee ID to delete allowance: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    List<Employee> employees = Employee.loadFromFile();
                    Employee emp = employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);

                    if (emp != null) {
                        emp.setAllowance(0);
                        System.out.println("Allowance deleted for " + emp.getName());
                      
                    } else {
                        System.out.println("Employee not found.");
                    }
                }
                case 7 -> {
                    return; // Back to main menu
                }
                default -> System.out.println("Invalid choice.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
    private static String getInput(Scanner scanner, String fieldName) {
    String input;
    while (true) {
        System.out.print("Enter " + fieldName + ": ");
        input = scanner.nextLine().trim(); 
        if (input.isEmpty()) {
            System.out.println("Invalid input. " + fieldName + " can't be empty. Please enter it again.");
        } else {
            break;
        }
    }
        return input;
    }

    private static double getDoubleInput(Scanner scanner, String fieldName) {
    double input = -1;
    while (true) {
        System.out.print("Enter " + fieldName + ": ");
        String line = scanner.nextLine().trim(); 
        
        if (line.isEmpty()) {
            System.out.println("Invalid input. " + fieldName + " can't be empty. Please enter a valid value.");
            continue; 
        }

        try {
            input = Double.parseDouble(line); 
            if (input < 0) {
                System.out.println("Invalid input. " + fieldName + " cannot be negative. Please enter a valid value.");
            } else {
                break; 
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a numeric value for " + fieldName + ".");
        }
    }
    return input; 
}
}