/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.IOException;
import java.util.*;

public class EmployeeManagement {
    private List<Employee> employees;

    public EmployeeManagement() {
        employees = new ArrayList<>();
    }

    // Add an employee
    public void addEmployee(Employee emp) throws IOException {
        employees.add(emp);
        emp.saveToFile(); // Save to file
        System.out.println("Employee added successfully.");
    }

    // Update employee
    public void updateEmployee(int id, String newEmail) throws Exception {
        boolean found = false;
        for (int i = 0; i < employees.size(); i++) {
            Employee emp = employees.get(i);
            if (emp.getId() == id) {
                Employee updatedEmployee = new Employee(emp.getId(), emp.getName(), emp.getGender(), newEmail, emp.getDob()) {};
                employees.set(i, updatedEmployee);
               
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Employee not found.");
        }
    }

    // Delete employee
    public void deleteEmployee(int id) {
        Iterator<Employee> iterator = employees.iterator();
        boolean found = false;
        while (iterator.hasNext()) {
            Employee emp = iterator.next();
            if (emp.getId() == id) {
                iterator.remove();
                
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Employee not found.");
        }
    }

}