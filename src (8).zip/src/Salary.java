/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author HP
 */
public class Salary {
    private double baseSalary;
    private double deductions;
    private double bonuses;

    public Salary(double baseSalary, double deductions, double bonuses) throws Exception {
        if (baseSalary <= 0) throw new Exception("Base salary must be positive.");
        if (deductions < 0) throw new Exception("Deductions cannot be negative.");
        if (bonuses < 0) throw new Exception("Bonuses cannot be negative.");

        this.baseSalary = baseSalary;
        this.deductions = deductions;
        this.bonuses = bonuses;
    }
    public double getBaseSalary() {
    return baseSalary;
}

public void setBaseSalary(double baseSalary) {
    this.baseSalary = baseSalary;
}


public double getDeductions() {
    return deductions;
}

public void setDeductions(double deductions) {
    this.deductions = deductions;
}


public double getBonuses() {
    return bonuses;
}

public void setBonuses(double bonuses) {
    this.bonuses = bonuses;
}
   public void saveToFile() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("salaries.txt", true))) {
            writer.write(baseSalary + "," + deductions + "," + bonuses);
            writer.newLine();
            
        } catch (IOException e) {
            System.err.println("An error occurred while saving the file: " + e.getMessage());
            throw e; 
        }
    }

    
    public static List<Salary> loadFromFile() throws IOException {
        List<Salary> salaries = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("salaries.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                Salary salary = new Salary(
                    Double.parseDouble(data[0]),
                    Double.parseDouble(data[1]),
                    Double.parseDouble(data[2])
                );
                salaries.add(salary);
            }
        } catch (Exception ex) {
            System.err.println("Error reading salary data: " + ex.getMessage());
        }
        return salaries;
    }
    public double calculateNetSalary() {
        return baseSalary - deductions + bonuses;
    }

}
