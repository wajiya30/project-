/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class PartTimeEmployee extends FullTimeEmployee {
    private int hoursWorked; 

    public PartTimeEmployee(int id, String name, String gender, String email, String dob, String department, int hoursWorked) throws Exception {
        super(id, name, gender, email, dob, department);
        if (hoursWorked < 0) {
            throw new Exception("Hours worked cannot be negative.");
        }
        this.hoursWorked = hoursWorked; 
    }

    public int getHoursWorked() { 
        return hoursWorked; 
    }

    @Override
    public double calculateSalary(double baseSalary, double deductions, double bonuses) {
        // Part-time employees have standard salary calculation
        return super.calculateSalary(baseSalary, deductions, bonuses); 
    }
}