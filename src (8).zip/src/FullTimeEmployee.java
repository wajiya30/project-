/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
 public class FullTimeEmployee extends Employee {
    private String department; // Added department attribute

    public FullTimeEmployee(int id, String name, String gender, String email, String dob, String department) throws Exception {
        super(id, name, gender, email, dob);
        if (department == null || department.trim().isEmpty()) {
            throw new Exception("Department cannot be empty.");
        }
        this.department = department; // Initialize department
    }

    public String getDepartment() { 
        return department; 
    }

    @Override
    public double calculateSalary(double baseSalary, double deductions, double bonuses) {
        // Full-time employees might get a different calculation
        return super.calculateSalary(baseSalary, deductions, bonuses) + 500; // Adding a bonus for full-time employees
    }
 }