/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class Allowance {
     private double transportAllowance;
    private double housingAllowance;
    private double mealAllowance;
    private double medicalAllowance;
    private double otherAllowances;

    public Allowance(double transportAllowance, double housingAllowance, double mealAllowance, double medicalAllowance, double otherAllowances) throws Exception {
        if (transportAllowance < 0) throw new Exception("Transport Allowance cannot be negative.");
        if (housingAllowance < 0) throw new Exception("Housing Allowance cannot be negative.");
        if (mealAllowance < 0) throw new Exception("Meal Allowance cannot be negative.");
        if (medicalAllowance < 0) throw new Exception("Medical Allowance cannot be negative.");
        if (otherAllowances < 0) throw new Exception("Other Allowances cannot be negative.");
        
        this.transportAllowance = transportAllowance;
        this.housingAllowance = housingAllowance;
        this.mealAllowance = mealAllowance;
        this.medicalAllowance = medicalAllowance;
        this.otherAllowances = otherAllowances;
    }
    public double getTransportAllowance() {
    return transportAllowance;
}

public void setTransportAllowance(double transportAllowance) {
    this.transportAllowance = transportAllowance;
}


public double getHousingAllowance() {
    return housingAllowance;
}

public void setHousingAllowance(double housingAllowance) {
    this.housingAllowance = housingAllowance;
}


public double getMealAllowance() {
    return mealAllowance;
}

public void setMealAllowance(double mealAllowance) {
    this.mealAllowance = mealAllowance;
}


public double getMedicalAllowance() {
    return medicalAllowance;
}

public void setMedicalAllowance(double medicalAllowance) {
    this.medicalAllowance = medicalAllowance;
}


public double getOtherAllowances() {
    return otherAllowances;
}

public void setOtherAllowances(double otherAllowances) {
    this.otherAllowances = otherAllowances;
}

    public double calculateTotalAllowances() {
        return transportAllowance + housingAllowance + mealAllowance + medicalAllowance + otherAllowances;
    }
}
