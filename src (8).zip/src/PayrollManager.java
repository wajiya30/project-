/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class PayrollManager {
    
    public void calculateSalary(Employee emp, Salary salary) {
        System.out.println("Calculating salary for: " + emp.getName());
        double netSalary = salary.calculateNetSalary();
        System.out.println("Net Salary: " + netSalary);
    }

    public void calculateAllowances(Employee emp, Allowance allowance) {
        System.out.println("Calculating allowances for: " + emp.getName());
        double totalAllowances = allowance.calculateTotalAllowances();
        System.out.println("Total Allowances: " + totalAllowances);
    }

}
