/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CreateCredentialsFile {
    public static void main(String[] args) {
        createCredentialsFile();
    }
    public static void createCredentialsFile() {
        String fileName = "credentials.txt"; 
        String content = "Wajiya,123\nFatima,123\nIzza,123\nHajra,123"; 

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(content);
            System.out.println("Credentials file created successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
    }
}
