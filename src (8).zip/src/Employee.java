/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

abstract class Employee {
    private int id;
    private String name;
    private String gender;
    private String email;
    private String dob;
    

    public Employee(int id, String name, String gender, String email, String dob) throws Exception {
        if (id <= 0) throw new Exception("ID cannot be zero or negative.");
        if (name == null || name.isEmpty()) throw new Exception("Name cannot be empty.");
        if (gender == null || gender.isEmpty()) throw new Exception("Gender cannot be empty.");
        if (email == null || email.isEmpty()) throw new Exception("Email cannot be empty.");
        if (dob == null || dob.isEmpty()) throw new Exception("Date of birth cannot be empty.");

        this.id = id;
        this.name = name;
        this.gender = gender;
        this.email = email;
        this.dob = dob;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getGender() { return gender; }
    public String getEmail() { return email; }
    public String getDob() { return dob; }
    
    public void saveToFile() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("employees.txt", true))) {
            writer.write(id + "," + name + "," + gender + "," + email + "," + dob);
            writer.newLine();
        }
    }

    public static List<Employee> loadFromFile() throws IOException {
        List<Employee> employees = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("employees.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                Employee emp = new Employee(
                    Integer.parseInt(data[0]), data[1], data[2], data[3], data[4]
                ) {};
                employees.add(emp);
            }
        } catch (Exception ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
        return employees;
    }

   
    public double calculateSalary(double baseSalary, double deductions, double bonuses) {
        return baseSalary - deductions + bonuses; 
    }

    double calculateAllowances(double transportAllowance, double housingAllowance, double mealAllowance, double medicalAllowance, double otherAllowances) {
               return transportAllowance + housingAllowance + mealAllowance + medicalAllowance + otherAllowances;
        
    }

 public void setSalary(double newSalary) {
    if (newSalary < 0) {
        throw new IllegalArgumentException("Salary cannot be negative.");
    }
 }
 
    public void setAllowance(double newAllowance) {
    if (newAllowance < 0) {
        throw new IllegalArgumentException("Allowance cannot be negative.");
     
}
    }}

